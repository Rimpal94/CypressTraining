describe('template spec', () => {
  it('passes', () => {
    cy.visit('http://secure.smartbearsoftware.com/samples/TestComplete11/WebOrders/Login.aspx?')
    /* ==== Generated with Cypress Studio ==== */
   // cy.get('#ctl00_MainContent_username').clear('T');
    cy.get('#ctl00_MainContent_username').type('Tester');
    cy.get('#ctl00_MainContent_password').type('test');
    cy.get('#ctl00_MainContent_login_button').click();
    cy.get('#ctl00_menu > :nth-child(3) > a').click();
    cy.get('#ctl00_MainContent_fmwOrder_ddlProduct').select('FamilyAlbum');
   // cy.get('#ctl00_MainContent_fmwOrder_txtQuantity').clear('01');
    cy.get('#ctl00_MainContent_fmwOrder_txtQuantity').type('010');
   // cy.get('#ctl00_MainContent_fmwOrder_txtUnitPrice').clear();
    cy.get('#ctl00_MainContent_fmwOrder_txtUnitPrice').type('5');
    //cy.get('#ctl00_MainContent_fmwOrder_txtDiscount').clear();
    cy.get('#ctl00_MainContent_fmwOrder_txtDiscount').type('15');
    //cy.get('#ctl00_MainContent_fmwOrder_txtTotal').clear();
    cy.get('#ctl00_MainContent_fmwOrder_txtTotal').type('680');
    cy.get(':nth-child(5) > .btn_dark').type('Calculate');
    cy.get(':nth-child(5) > .btn_dark').click();
    //cy.get('#ctl00_MainContent_fmwOrder_txtName').clear('Rimpal');
    cy.get('#ctl00_MainContent_fmwOrder_txtName').type('Rimpal');
    //cy.get('#ctl00_MainContent_fmwOrder_TextBox2').clear('Btm');
    cy.get('#ctl00_MainContent_fmwOrder_TextBox2').type('Btm');
    //cy.get('#ctl00_MainContent_fmwOrder_TextBox3').clear('BLR');
    cy.get('#ctl00_MainContent_fmwOrder_TextBox3').type('BLR');
    //cy.get('#ctl00_MainContent_fmwOrder_TextBox4').clear('KA');
    cy.get('#ctl00_MainContent_fmwOrder_TextBox4').type('KA');
    //cy.get('#ctl00_MainContent_fmwOrder_TextBox5').clear('560076');
    cy.get('#ctl00_MainContent_fmwOrder_TextBox5').type('560076');
    cy.get('#ctl00_MainContent_fmwOrder_cardList_1').check();
    //cy.get('#ctl00_MainContent_fmwOrder_TextBox6').clear('1234');
    cy.get('#ctl00_MainContent_fmwOrder_TextBox6').type('1234');
    //cy.get('#ctl00_MainContent_fmwOrder_TextBox1').clear('1234');
    cy.get('#ctl00_MainContent_fmwOrder_TextBox1').type('12/34');
    cy.wait(3000);
    cy.get('#ctl00_MainContent_fmwOrder_InsertButton').click();
    /* ==== End Cypress Studio ==== */
  })
})

// type definitions for Cypress object "cy"
/// <reference types="cypress" />

describe('Fetching Data from Fixture file->TestData.json', function () {

    //Use the cy.fixture() method to pull data from fixture file
    before(function () {
      cy.fixture('MultiData_Login_WebOrder').then(function (data) {
        this.data = data;
      })
    })
  
    it('Visits the OrangeHRM Page and Perform Login Action', function () {
      //Visit the OrnageHRM Website
      for (var i = 0; i < this.data.Login.length; i++) {
        cy.visit("http://secure.smartbearsoftware.com/samples/TestComplete11/WebOrders/Login.aspx");
  
  
  
        // Enter UserName and Password
        cy.log("USER :" + i + 1)
        cy.get('#ctl00_MainContent_username').type(this.data.Login[i].uname)
        cy.get('#ctl00_MainContent_password').type(this.data.Login[i].password)
        cy.get('#ctl00_MainContent_login_button').click()
        //Verify Admin URL in navigation bar
        cy.url().should('include', '/TestComplete11/WebOrders/default.aspx')
        //Logout from application
        cy.get('#ctl00_logout').click()
        cy.get('#ctl00_MainContent_login_button').should('contain.value', "Login")
      }
    })
  })
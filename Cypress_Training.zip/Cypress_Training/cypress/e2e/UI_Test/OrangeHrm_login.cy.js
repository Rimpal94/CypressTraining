describe('template spec', () => {
    it('passes', () => {
      cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
      /* ==== Generated with Cypress Studio ==== */
      //cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').clear('Admin');
      cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type('Admin');
     // cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').clear('a');
      cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type('admin123');
      //Verify Login
      cy.get('.oxd-text--h5').should('contain','Login')
      cy.get('.oxd-button').click();
      //Verify HomepAge Dashboard title
      cy.get('.oxd-topbar-header-breadcrumb > .oxd-text').should('contain','Dashboard')
      cy.get(':nth-child(1) > .oxd-main-menu-item > .oxd-text').click();
      //Verify Add button visible in Admin section
      cy.get('.orangehrm-header-container > .oxd-button').should('contain','Add')
      cy.get('.oxd-userdropdown-tab > .oxd-icon').click();
      cy.get(':nth-child(4) > .oxd-userdropdown-link').click();
      //Validate logout 
      cy.url().should('include','/auth/login')
      //Click on Forget Password link
      cy.get('.orangehrm-login-forgot > .oxd-text').click();
      //Click on Cancel
      cy.get('#app > div.orangehrm-forgot-password-container > div.orangehrm-forgot-password-wrapper > div > form > div.orangehrm-forgot-password-button-container > button.oxd-button.oxd-button--large.oxd-button--ghost.orangehrm-forgot-password-button.orangehrm-forgot-password-button--cancel').click();

      /* ==== End Cypress Studio ==== */
    })
  })
/// <reference types="cypress" />

describe('template spec', () => {
  it('passes', () => {
    cy.visit('http://secure.smartbearsoftware.com/samples/TestComplete11/WebOrders/Login.aspx?')
    //cy.get("#ctl00$MainContent$username").type("Tester")
    cy.get("#ctl00_MainContent_username").type("Tester")
    cy.get("#ctl00_MainContent_password").type("test")
    cy.get("#ctl00_MainContent_login_button").click();
    cy.get('#ctl00_menu > :nth-child(3) > a').click();
    //Verify order page link
    cy.url().should('include','/Process.aspx')
    //Verify order page title
    cy.get('h2').should('contain','Order')
    cy.get('#ctl00_menu > :nth-child(1) > a').click();
    cy.get('#ctl00_MainContent_btnCheckAll').click();
    cy.get('#ctl00_MainContent_orderGrid_ctl05_OrderSelector').click();
    cy.get('#ctl00_MainContent_orderGrid_ctl08_OrderSelector').click();
    cy.get("#ctl00_logout").click();
  })
})
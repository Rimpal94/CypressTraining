describe('Create Order -> Verify Order', () => {
  
  it('Test Case 1- Create Order', () => {
    cy.visit('http://secure.smartbearsoftware.com/samples/TestComplete11/WebOrders/Login.aspx')
    /* ==== Generated with Cypress Studio ==== */
    cy.get('#ctl00_MainContent_username').type('Tester');
    cy.get('#ctl00_MainContent_password').type('test');
    cy.get('#ctl00_MainContent_login_button').click();
    cy.get('#ctl00_menu > :nth-child(3) > a').click()
    cy.get('#ctl00_MainContent_fmwOrder_ddlProduct').select('FamilyAlbum');
    //cy.get('[colspan="2"] > :nth-child(3) > :nth-child(2)').click();
    cy.get('#ctl00_MainContent_fmwOrder_txtQuantity').type('5');
    cy.get('#ctl00_MainContent_fmwOrder_txtName').type('Abhi');
    cy.get('#ctl00_MainContent_fmwOrder_TextBox2').type('BTM');
    cy.get('#ctl00_MainContent_fmwOrder_TextBox3').type('Bangalore');
    cy.get('#ctl00_MainContent_fmwOrder_TextBox5').type('560076');
    cy.get('#ctl00_MainContent_fmwOrder_cardList_0').check();
    cy.get('#ctl00_MainContent_fmwOrder_TextBox6').type('123456789');
    cy.get('#ctl00_MainContent_fmwOrder_TextBox1').type('12/23');
    cy.get('#ctl00_MainContent_fmwOrder_InsertButton').click();
    // Verify that Successful message get generated
    cy.xpath("//strong[normalize-space()='New order has been successfully added.']").should('contain',"New order has been successfully added.")
    //Logout from application and VErify that user has signed out
    cy.get('#ctl00_logout').click();
    cy.url().should('include','/WebOrders/Login.aspx')
    /* ==== End Cypress Studio ==== */
  })
})
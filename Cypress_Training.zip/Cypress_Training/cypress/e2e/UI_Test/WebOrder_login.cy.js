describe('template spec', () => {
  it('passes', () => {
    cy.visit('http://secure.smartbearsoftware.com/samples/TestComplete11/WebOrders/Login.aspx?')
    /* ==== Generated with Cypress Studio ==== */
    cy.xpath("//input[@name='ctl00$MainContent$username']").type('Tester');
    cy.xpath("//input[@name='ctl00$MainContent$password']").type('test');
    cy.get('#ctl00_MainContent_login_button').click();
  })
})
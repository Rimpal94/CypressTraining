// type definitions for Cypress object "cy"
/// <reference types="cypress" />

describe('Child Tab Example', function () {
    // test case
    it.skip('Child Tab -Test 1', function (){
        // launch the url
        cy.visit("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        // removing the target attribute from the link with removeAttr()
        cy.get("a[href='http://www.orangehrm.com']").invoke('removeAttr', 'target').click();
        // assertion to verify the current Url
        cy.url().should('include','https://www.orangehrm.com/');
        //cy.get('.mui-btn').click()
        // moving back to the parent tab with the help of go() method
        //cy.go('back');
        cy.go('back');
        // assertion to verify the current Url
        cy.url().should('include','/web/index.php/auth/login');
     });

         // test case
    it('Flipcart Example', function (){
        // launch the url
        cy.visit("https://www.flipkart.com/");

        cy.xpath("//img[@alt='Mobiles']").click()
        cy.wait(5000)
        cy.xpath("//a[normalize-space()='SAMSUNG Galaxy F54 5G (Stardust Silver, 256 GB)']").invoke('removeAttr', 'target').click();
        //cy.wait(5000)
        //cy.get('[data-tkid="M_6426fbf0-ceb6-45a1-ba1d-62a277d46f58_7.Q1PDG4YW86MF"] > .h1Fvn6 > ._HYyiu > ._1aPR5_').click()

       /* cy.xpath('//*[@id="container"]/div/div[3]/div/div[2]/div[2]/div/div/div/a')
        .invoke('removeAttr', 'target').click();*/
        //cy.visit('https://www.flipkart.com/realme-11-pro-5g-astral-black-256-gb/p/itm5647cce338e55?pid=MOBGPU8HRUUHYEWE&lid=LSTMOBGPU8HRUUHYEWEOXYFS1&marketplace=FLIPKART&store=tyy%2F4io&srno=b_1_1&otracker=clp_metro_expandable_2_7.metroExpandable.METRO_EXPANDABLE_Shop%2BNow_mobile-phones-store_Q1PDG4YW86MF_wp4&fm=neo%2Fmerchandising&iid=en_Tq9uT8TDJ%2Ftvif4aYLmxfyW3MEJPy%2F4EEcD1gRqGvCJSgMu3w3d2%2BLlhaccsunA%2FxAuuAhLgdpXGxhYYAughWQ%3D%3D&ppt=clp&ppn=mobile-phones-store&ssid=qd0n6ytje80000001687416012270')
        cy.url().should('include','/samsung')
        cy.go('back')
        cy.url().should('include','/mobile')
     });
})
// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
Cypress.Commands.add('Login_Weborder', (uname, password) => {
    cy.session([uname, password], () => {
      cy.visit('http://secure.smartbearsoftware.com/samples/TestComplete11/WebOrders/Login.aspx')
      // Enter UserName and Password
      cy.get('#ctl00_MainContent_username').type(uname);
      cy.get('#ctl00_MainContent_password').type(password);
      cy.get('#ctl00_MainContent_login_button').click();
      //Verify that user has logged in
      cy.url().should('include','/TestComplete11/WebOrders/default.aspx')
    })
  
  })
  //Below is Login command ,using this user can login to any application
Cypress.Commands.add('LoginToAnyApp', (unameloc, upassloc, lbuttonloc, uname, upass) => {
    // Enter UserName and Password
  
    cy.get(unameloc).type(uname)
    cy.get(upassloc).type(upass)
    cy.get(lbuttonloc).click()
  })
const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    experimentalStudio :true,
    specPattern : "cypress/e2e/UI_Test",
    screenshotOnRunFailure : true,
    //video: false,
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
  },
});
